from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies=[('store','0002_product_image_upload')]
    operations=[
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
                ('title',models.CharField(max_length=200,verbose_name='عنوان')),
                ('message',models.TextField(verbose_name='متن پیام')),
                ('notification_type',models.CharField(choices=[('system','سیستمی'),('promo','تخفیف'),('order','سفارش'),('shipping','ارسال')],default='system',max_length=20,verbose_name='نوع')),
                ('is_active',models.BooleanField(default=True,verbose_name='فعال')),
                ('created_at',models.DateTimeField(auto_now_add=True)),
                ('updated_at',models.DateTimeField(auto_now=True)),
            ],
        ),
    ]
