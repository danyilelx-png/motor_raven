import json,uuid
from functools import wraps
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from .models import User,Category,Product,Cart,CartItem,Address,Order,OrderItem,ContactMessage,Notification

def image_url(p):
 name=getattr(p.image,'name','') or ''
 if not name:return ''
 # Existing bundled images stay served from static; newly uploaded images use MEDIA.
 if name.startswith('images/'):
  return '/static/' + name.lstrip('/')
 return '/media/' + name.lstrip('/')
def body(r):
 try:return json.loads(r.body or '{}')
 except:return {}
def auth(fn):
 @wraps(fn)
 def w(r,*a,**k):
  if not r.user.is_authenticated:return JsonResponse({'detail':'ورود به حساب کاربری الزامی است.'},status=401)
  return fn(r,*a,**k)
 return w
def pdata(p):return {'id':p.id,'name':p.name,'slug':p.slug,'brand':p.brand,'category':p.category.name,'description':p.description,'engine_cc':p.engine_cc,'horsepower':float(p.horsepower),'weight_kg':float(p.weight_kg),'price':p.price,'image':image_url(p),'stock':p.stock}
def getcart(r):
 if r.user.is_authenticated:
  c,_=Cart.objects.get_or_create(user=r.user)
 else:
  if not r.session.session_key:r.session.create()
  c,_=Cart.objects.get_or_create(session_key=r.session.session_key)
 return c
def cdata(c):
 items=[]
 for i in c.items.select_related('product'):
  items.append({'id':i.product.id,'name':i.product.name,'image':image_url(i.product),'price':i.product.price,'qty':i.quantity,'line_total':i.product.price*i.quantity})
 return {'items':items,'count':sum(x['qty'] for x in items),'subtotal':sum(x['line_total'] for x in items),'total':sum(x['line_total'] for x in items)}
@require_http_methods(['GET'])
def products(r):
 qs=Product.objects.filter(is_active=True).select_related('category');q=r.GET.get('q','').strip();brand=r.GET.get('brand','').strip();cat=r.GET.get('category','').strip();sort=r.GET.get('sort','newest')
 if q:qs=qs.filter(name__icontains=q)|qs.filter(brand__icontains=q)
 if brand:qs=qs.filter(brand__iexact=brand)
 if cat:qs=qs.filter(category__slug=cat)
 if sort=='price_asc':qs=qs.order_by('price')
 elif sort=='price_desc':qs=qs.order_by('-price')
 else:qs=qs.order_by('-created_at')
 return JsonResponse({'results':[pdata(p) for p in qs]})
@require_http_methods(['GET'])
def product(r,pk):
 try:p=Product.objects.select_related('category').get(pk=pk,is_active=True)
 except Product.DoesNotExist:return JsonResponse({'detail':'محصول پیدا نشد.'},status=404)
 return JsonResponse(pdata(p))
@require_http_methods(['GET'])
def notifications(r):
    qs=Notification.objects.filter(is_active=True).order_by('-created_at')
    return JsonResponse({'results':[
        {'id':n.id,'title':n.title,'message':n.message,'type':n.notification_type,
         'created_at':n.created_at.isoformat()} for n in qs
    ]})

@require_http_methods(['GET'])
def categories(r):return JsonResponse({'results':[{'id':c.id,'name':c.name,'slug':c.slug} for c in Category.objects.all()]})
@require_http_methods(['GET'])
def cart(r):return JsonResponse(cdata(getcart(r)))
@require_http_methods(['POST'])
def cart_add(r):
 d=body(r);pid=d.get('product_id',d.get('id'));q=int(d.get('quantity',1));
 if q<1:return JsonResponse({'detail':'تعداد نامعتبر است.'},status=400)
 try:p=Product.objects.get(pk=pid,is_active=True)
 except:return JsonResponse({'detail':'محصول پیدا نشد.'},status=404)
 c=getcart(r);i,_=CartItem.objects.get_or_create(cart=c,product=p);new=i.quantity+q
 if new>p.stock:return JsonResponse({'detail':'موجودی کافی نیست.'},status=400)
 i.quantity=new;i.save();return JsonResponse(cdata(c),status=201)
@require_http_methods(['POST'])
def cart_update(r):
 d=body(r);pid=d.get('product_id',d.get('id'));q=int(d.get('quantity',d.get('qty',1)));c=getcart(r)
 try:i=CartItem.objects.select_related('product').get(cart=c,product_id=pid)
 except CartItem.DoesNotExist:return JsonResponse({'detail':'آیتم سبد پیدا نشد.'},status=404)
 if q<=0:i.delete()
 elif q<=i.product.stock:i.quantity=q;i.save()
 else:return JsonResponse({'detail':'موجودی کافی نیست.'},status=400)
 return JsonResponse(cdata(c))
@require_http_methods(['POST'])
def cart_remove(r):
 d=body(r);getcart(r).items.filter(product_id=d.get('product_id',d.get('id'))).delete();return JsonResponse(cdata(getcart(r)))
@require_http_methods(['POST'])
def register(r):
 d=body(r);phone=str(d.get('phone','')).strip();pw=d.get('password','')
 if not phone or not pw:return JsonResponse({'detail':'شماره موبایل و رمز عبور الزامی است.'},status=400)
 if User.objects.filter(phone=phone).exists():return JsonResponse({'detail':'این شماره قبلاً ثبت شده است.'},status=400)
 u=User(phone=phone,first_name=d.get('first_name',''),last_name=d.get('last_name',''),email=d.get('email',''))
 try:validate_password(pw,u)
 except ValidationError as e:return JsonResponse({'detail':' '.join(e.messages)},status=400)
 u.set_password(pw);u.save();login(r,u);return JsonResponse({'user':{'id':u.id,'phone':u.phone,'first_name':u.first_name,'last_name':u.last_name}},status=201)
@require_http_methods(['POST'])
def login_view(r):
 d=body(r);u=authenticate(r,username=str(d.get('phone','')).strip(),password=d.get('password',''))
 if not u:return JsonResponse({'detail':'شماره موبایل یا رمز عبور نادرست است.'},status=400)
 login(r,u);return JsonResponse({'user':{'id':u.id,'phone':u.phone,'first_name':u.first_name,'last_name':u.last_name}})
@require_http_methods(['POST'])
def logout_view(r):logout(r);return JsonResponse({'ok':True})
@require_http_methods(['GET'])
def me(r):
 if not r.user.is_authenticated:return JsonResponse({'authenticated':False})
 u=r.user;return JsonResponse({'authenticated':True,'user':{'id':u.id,'phone':u.phone,'first_name':u.first_name,'last_name':u.last_name,'email':u.email}})
def adata(a):return {'id':a.id,'title':a.title,'recipient_name':a.recipient_name,'phone':a.phone,'province':a.province,'city':a.city,'postal_code':a.postal_code,'address':a.address,'is_default':a.is_default}
@auth
@require_http_methods(['GET','POST'])
def addresses(r):
 if r.method=='GET':return JsonResponse({'results':[adata(a) for a in r.user.addresses.order_by('-is_default','-created_at')]})
 d=body(r);a=Address.objects.create(user=r.user,title=d.get('title') or 'آدرس من',recipient_name=d.get('recipient_name',''),phone=d.get('phone',r.user.phone),province=d.get('province',''),city=d.get('city',''),postal_code=d.get('postal_code',''),address=d.get('address',''),is_default=bool(d.get('is_default',False)));return JsonResponse(adata(a),status=201)
@auth
@require_http_methods(['PUT','PATCH','DELETE'])
def address(r,pk):
 try:a=Address.objects.get(pk=pk,user=r.user)
 except Address.DoesNotExist:return JsonResponse({'detail':'آدرس پیدا نشد.'},status=404)
 if r.method=='DELETE':a.delete();return JsonResponse({'ok':True})
 d=body(r)
 for f in ['title','recipient_name','phone','province','city','postal_code','address']:
  if f in d:setattr(a,f,d[f])
 if 'is_default' in d:a.is_default=bool(d['is_default'])
 a.save();return JsonResponse(adata(a))
@auth
@require_http_methods(['GET','POST'])
def orders(r):
 if r.method=='GET':
  out=[]
  for o in r.user.orders.prefetch_related('items').order_by('-created_at'):out.append({'id':o.id,'total':o.total,'status':o.status,'status_label':o.get_status_display(),'tracking_code':o.tracking_code,'created_at':o.created_at.isoformat(),'items':[{'product_id':i.product_id,'name':i.product_name,'price':i.unit_price,'quantity':i.quantity} for i in o.items.all()]})
  return JsonResponse({'results':out})
 d=body(r);c=getcart(r)
 try:a=Address.objects.get(pk=d.get('address_id'),user=r.user)
 except Address.DoesNotExist:return JsonResponse({'detail':'آدرس معتبر نیست.'},status=400)
 items=list(c.items.select_related('product'))
 if not items:return JsonResponse({'detail':'سبد خرید خالی است.'},status=400)
 with transaction.atomic():
  for i in items:
   if i.quantity>i.product.stock:raise ValueError('موجودی کافی نیست.')
  total=sum(i.product.price*i.quantity for i in items);o=Order.objects.create(user=r.user,address=a,total=total,status='pending',tracking_code='RM-'+uuid.uuid4().hex[:8].upper())
  for i in items:OrderItem.objects.create(order=o,product=i.product,product_name=i.product.name,unit_price=i.product.price,quantity=i.quantity)
  c.items.all().delete()
 return JsonResponse({'id':o.id,'total':o.total,'status':o.status,'tracking_code':o.tracking_code},status=201)
@require_http_methods(['POST'])
def contact(r):
 d=body(r);m=ContactMessage.objects.create(name=d.get('name',''),phone=d.get('phone',''),message=d.get('message',''));return JsonResponse({'ok':True,'id':m.id},status=201)
