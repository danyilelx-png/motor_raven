from django import forms
from django.contrib import admin
from django.utils.html import format_html
from .models import User, Category, Product, Address, Cart, CartItem, Order, OrderItem, ContactMessage, Notification


class ProductAdminForm(forms.ModelForm):
    """Explicit upload widget so the Product image is always a real file picker."""
    image = forms.ImageField(
        required=False,
        label='تصویر محصول',
        widget=forms.ClearableFileInput(attrs={
            'accept': 'image/*',
        }),
        help_text='یک تصویر از محصول انتخاب کنید (JPG, PNG, WEBP و ...).',
    )

    class Meta:
        model = Product
        fields = '__all__'


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    form = ProductAdminForm
    list_display = ('name', 'brand', 'price', 'stock', 'is_active', 'image')
    search_fields = ('name', 'brand')
    list_filter = ('brand', 'is_active', 'category')
    readonly_fields = ('image_preview',)

    fieldsets = (
        ('اطلاعات اصلی', {
            'fields': ('name', 'slug', 'brand', 'category', 'description')
        }),
        ('مشخصات فنی', {
            'fields': ('engine_cc', 'horsepower', 'weight_kg')
        }),
        ('فروش', {
            'fields': ('price', 'stock', 'image', 'image_preview', 'is_active')
        }),
    )

    def image_preview(self, obj):
        if not obj or not obj.image:
            return 'بدون تصویر'
        return format_html(
            '<img src="{}" style="max-height:180px;max-width:280px;border-radius:8px;object-fit:contain;" alt="پیش‌نمایش محصول">',
            obj.image.url,
        )

    image_preview.short_description = 'پیش‌نمایش تصویر'


admin.site.register(User)
admin.site.register(Category)
admin.site.register(Address)
admin.site.register(Cart)
admin.site.register(CartItem)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ContactMessage, Notification)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display=('title','notification_type','is_active','created_at')
    list_filter=('notification_type','is_active')
    search_fields=('title','message')
    ordering=('-created_at',)
    fieldsets=(
        ('پیام اعلان برای همه کاربران', {'fields': ('title','message','notification_type','is_active')}),
    )
