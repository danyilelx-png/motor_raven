from django.http import Http404
from django.shortcuts import render
ALLOWED={'index.html','index(1).html','search.html','product.html','cart.html','checkout.html','login.html','account.html','wishlist.html','notifications.html','about.html','contact.html'}
def page(request,name):
 if name not in ALLOWED:raise Http404
 return render(request,name)
