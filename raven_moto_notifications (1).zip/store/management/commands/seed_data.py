from django.core.management.base import BaseCommand
from store.models import Category,Product
DATA=[
('Yamaha','Yamaha R7 2024','yamaha-r7-2024',975000000,'images/moto7.jpeg',689,73,188),('Yamaha','Yamaha MT-07 2024','yamaha-mt-07-2024',650000000,'images/moto3.jpeg',689,73,184),('Yamaha','Yamaha MT-09 2024','yamaha-mt-09-2024',990000000,'images/moto6.jpeg',890,119,193),('Yamaha','Yamaha Tracer 9 GT 2024','yamaha-tracer-9-gt-2024',1150000000,'images/moto8.jpeg',890,117,220),('Yamaha','Yamaha XSR900 2024','yamaha-xsr900-2024',920000000,'images/moto9.jpeg',889,117,193),('Yamaha','Yamaha YZF-R1 2024','yamaha-yzf-r1-2024',1450000000,'images/moto10.jpeg',998,200,201),('BMW','BMW F850GS','bmw-f850gs',1180000000,'images/moto1.jpeg',853,95,233),('Ducati','Ducati Monster 2024','ducati-monster-2024',1200000000,'images/moto2.jpeg',937,111,166),('Honda','Honda CBR500R','honda-cbr500r',720000000,'images/moto4.jpeg',471,47,192),('Kawasaki','Kawasaki Vulcan S','kawasaki-vulcan-s',850000000,'images/moto5.jpeg',649,61,229),('Zero','Zero SR/F','zero-srf',1250000000,'images/moto1.jpeg',0,110,226)]
class Command(BaseCommand):
 def handle(self,*a,**k):
  cats={}
  for brand in sorted({x[0] for x in DATA}):cats[brand]=Category.objects.get_or_create(name=brand,slug=brand.lower())[0]
  for brand,name,slug,price,image,cc,hp,weight in DATA:
   Product.objects.update_or_create(slug=slug,defaults={'name':name,'brand':brand,'category':cats[brand],'price':price,'image':image,'engine_cc':cc,'horsepower':hp,'weight_kg':weight,'stock':5,'description':f'{name}؛ محصول نو با ضمانت اصالت.'})
  self.stdout.write(self.style.SUCCESS(f'Seeded {len(DATA)} products.'))
