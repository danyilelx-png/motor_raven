from django.core.management.base import BaseCommand
from store.models import User

ADMIN_PHONE = '09120000000'
ADMIN_PASSWORD = 'RavenAdmin@2026'

class Command(BaseCommand):
    help = 'Create or update the default RAVEN MOTO admin account.'

    def handle(self, *args, **options):
        user, created = User.objects.get_or_create(phone=ADMIN_PHONE, defaults={
            'is_staff': True,
            'is_superuser': True,
            'is_active': True,
        })
        user.is_staff = True
        user.is_superuser = True
        user.is_active = True
        user.set_password(ADMIN_PASSWORD)
        user.save()
        action = 'created' if created else 'updated'
        self.stdout.write(self.style.SUCCESS(f'Default admin {action}.'))
        self.stdout.write(f'Phone: {ADMIN_PHONE}')
        self.stdout.write(f'Password: {ADMIN_PASSWORD}')
