from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import MinValueValidator
class User(AbstractUser):
 username=None
 phone=models.CharField(max_length=20,unique=True)
 email=models.EmailField(blank=True)
 USERNAME_FIELD='phone'
 REQUIRED_FIELDS=[]
 def __str__(self): return self.phone
class Category(models.Model):
 name=models.CharField(max_length=120,unique=True); slug=models.SlugField(max_length=140,unique=True)
 def __str__(self): return self.name
class Product(models.Model):
 name=models.CharField(max_length=200); slug=models.SlugField(max_length=220,unique=True); brand=models.CharField(max_length=100)
 category=models.ForeignKey(Category,on_delete=models.PROTECT,related_name='products'); description=models.TextField(blank=True)
 engine_cc=models.PositiveIntegerField(default=0); horsepower=models.DecimalField(max_digits=7,decimal_places=1,default=0); weight_kg=models.DecimalField(max_digits=7,decimal_places=1,default=0)
 price=models.PositiveBigIntegerField(validators=[MinValueValidator(0)]); image=models.ImageField(upload_to='products/',blank=True,null=True); stock=models.PositiveIntegerField(default=0); is_active=models.BooleanField(default=True)
 created_at=models.DateTimeField(auto_now_add=True); updated_at=models.DateTimeField(auto_now=True)
 def __str__(self): return self.name
class Address(models.Model):
 user=models.ForeignKey(User,on_delete=models.CASCADE,related_name='addresses'); title=models.CharField(max_length=80,default='آدرس من'); recipient_name=models.CharField(max_length=150); phone=models.CharField(max_length=20); province=models.CharField(max_length=100,blank=True); city=models.CharField(max_length=100); postal_code=models.CharField(max_length=20,blank=True); address=models.TextField(); is_default=models.BooleanField(default=False); created_at=models.DateTimeField(auto_now_add=True)
 def save(self,*args,**kwargs):
  super().save(*args,**kwargs)
  if self.is_default: Address.objects.filter(user=self.user).exclude(pk=self.pk).update(is_default=False)
 def __str__(self): return f'{self.title} - {self.user.phone}'
class Cart(models.Model):
 user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='cart',null=True,blank=True); session_key=models.CharField(max_length=80,unique=True,null=True,blank=True); updated_at=models.DateTimeField(auto_now=True)
class CartItem(models.Model):
 cart=models.ForeignKey(Cart,on_delete=models.CASCADE,related_name='items'); product=models.ForeignKey(Product,on_delete=models.CASCADE); quantity=models.PositiveIntegerField(default=1,validators=[MinValueValidator(1)])
 class Meta: constraints=[models.UniqueConstraint(fields=['cart','product'],name='unique_cart_product')]
class Order(models.Model):
 STATUS_CHOICES=[('pending','در انتظار پرداخت'),('processing','در حال پردازش'),('shipping','در حال ارسال'),('delivered','تحویل شده'),('cancelled','لغو شده')]
 user=models.ForeignKey(User,on_delete=models.PROTECT,related_name='orders'); address=models.ForeignKey(Address,on_delete=models.PROTECT,related_name='orders'); total=models.PositiveBigIntegerField(default=0); status=models.CharField(max_length=20,choices=STATUS_CHOICES,default='pending'); tracking_code=models.CharField(max_length=80,blank=True); created_at=models.DateTimeField(auto_now_add=True); updated_at=models.DateTimeField(auto_now=True)
 def __str__(self): return f'#{self.pk}'
class OrderItem(models.Model):
 order=models.ForeignKey(Order,on_delete=models.CASCADE,related_name='items'); product=models.ForeignKey(Product,on_delete=models.PROTECT); product_name=models.CharField(max_length=200); unit_price=models.PositiveBigIntegerField(); quantity=models.PositiveIntegerField()
class ContactMessage(models.Model):
 name=models.CharField(max_length=150); phone=models.CharField(max_length=30,blank=True); message=models.TextField(); created_at=models.DateTimeField(auto_now_add=True)

class Notification(models.Model):
    TYPE_CHOICES=[
        ('system','سیستمی'),
        ('promo','تخفیف'),
        ('order','سفارش'),
        ('shipping','ارسال'),
    ]
    title=models.CharField(max_length=200,verbose_name='عنوان')
    message=models.TextField(verbose_name='متن پیام')
    notification_type=models.CharField(max_length=20,choices=TYPE_CHOICES,default='system',verbose_name='نوع')
    is_active=models.BooleanField(default=True,verbose_name='فعال')
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    def __str__(self): return self.title
