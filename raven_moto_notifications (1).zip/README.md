# RAVEN MOTO — Complete Django Backend

فرانت‌اند HTML/CSS/Vanilla JavaScript پروژه حفظ شده و به Django متصل شده است. هیچ React/Vue/Angular استفاده نشده است.

## اجرای سریع در Windows

دو بار روی `setup_admin.bat` بزنید. این فایل:
1. محیط مجازی می‌سازد.
2. Django را نصب می‌کند.
3. migrationها را اجرا می‌کند.
4. محصولات اولیه را وارد می‌کند.
5. ادمین آماده را می‌سازد.
6. سرور را اجرا می‌کند.

### ورود به Admin

`http://127.0.0.1:8000/admin/`

- Phone: `09120000000`
- Password: `RavenAdmin@2026`

بعد از اولین ورود، رمز را تغییر دهید.

## اجرای دستی

```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_data
python manage.py setup_admin
python manage.py runserver
```

## API

GET:
- `/api/products/`
- `/api/products/<id>/`
- `/api/categories/`
- `/api/search/`
- `/api/cart/`
- `/api/orders/`
- `/api/addresses/`

POST:
- `/api/login/`
- `/api/register/`
- `/api/logout/`
- `/api/cart/add/`
- `/api/cart/update/`
- `/api/cart/remove/`
- `/api/orders/`
- `/api/addresses/`
- `/api/contact/`

PUT/PATCH/DELETE:
- `/api/addresses/<id>/`

## ساختار فرانت‌اند

CSS اصلی در `css/` و نسخه سرو‌شده توسط Django در `static/css/` قرار دارد.
تصاویر اصلی در `images/` و `static/images/` قرار دارند.
JavaScript در `js/` و `static/js/` قرار دارد.

طراحی، RTL، responsive و فایل‌های تصویری فرانت‌اند بدون بازطراحی نگه داشته شده‌اند.


## اعلان سراسری
از پنل Django Admin وارد بخش «Notifications» شوید. یک عنوان و متن پیام ثبت کنید و گزینه «فعال» را روشن بگذارید؛ پیام به‌صورت خودکار در صفحه اعلان‌های همه کاربران نمایش داده می‌شود. اعلان‌های غیرفعال برای کاربران نمایش داده نمی‌شوند.
