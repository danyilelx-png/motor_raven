document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.color-opt').forEach(opt => opt.addEventListener('click', () => {
    opt.parentElement.querySelectorAll('.color-opt').forEach(o => o.classList.remove('active')); opt.classList.add('active');
  }));
  document.querySelectorAll('.pdp-thumb').forEach((thumb,i,all)=>thumb.addEventListener('click',()=>{
    all.forEach(t=>t.classList.remove('active')); thumb.classList.add('active');
    const src=thumb.getAttribute('data-src'); const img=document.getElementById('mainProductImg'); if(src&&img) img.src=src;
    const c=document.querySelector('.pdp-img-count'); if(c)c.textContent=`${i+1} / ${all.length}`;
  }));
  document.querySelectorAll('.pdp-tab').forEach(tab=>tab.addEventListener('click',()=>{
    document.querySelectorAll('.pdp-tab').forEach(t=>t.classList.remove('active')); document.querySelectorAll('.pdp-panel').forEach(p=>p.classList.remove('active'));
    tab.classList.add('active'); const p=document.getElementById('tab-'+tab.dataset.tab); if(p)p.classList.add('active');
  }));
  document.querySelectorAll('.search-box input').forEach(input=>input.addEventListener('keypress',e=>{if(e.key==='Enter') location.href='search.html?q='+encodeURIComponent(input.value)}));
  document.querySelectorAll('.search-box button').forEach(btn=>btn.addEventListener('click',()=>{const i=btn.closest('.search-box')?.querySelector('input');location.href='search.html?q='+encodeURIComponent(i?.value||'')}));
});
function showToast(msg){let t=document.getElementById('raven-toast');if(!t){t=document.createElement('div');t.id='raven-toast';t.style.cssText='position:fixed;bottom:100px;left:50%;transform:translateX(-50%);background:#2ecc71;color:#fff;padding:12px 24px;border-radius:10px;font-family:inherit;z-index:9999;box-shadow:0 8px 24px #0003';document.body.appendChild(t)}t.textContent=msg;t.style.opacity='1';clearTimeout(t._timer);t._timer=setTimeout(()=>t.style.opacity='0',2000)}

async function updateNotificationBadge(){
  try{
    const res=await fetch('/api/notifications/',{credentials:'same-origin'});
    if(!res.ok)return;
    const data=await res.json();
    const count=(data.results||[]).length;
    document.querySelectorAll('.header-actions a[href="notifications.html"] .badge').forEach(b=>{
      b.textContent=count;
      b.style.display=count>0?'flex':'none';
    });
  }catch(e){}
}

document.addEventListener('DOMContentLoaded',updateNotificationBadge);
