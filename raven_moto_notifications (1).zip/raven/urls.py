from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView
from store.views import page

# Keep compatibility with older bookmarks/links that used the previous app label
# (core). The Product model now lives in the store app.
urlpatterns=[
    path('admin/core/product/', RedirectView.as_view(url='/admin/store/product/', permanent=False)),
    path('admin/core/product/<int:object_id>/', RedirectView.as_view(url='/admin/store/product/%(object_id)s/change/', permanent=False)),
    path('admin/',admin.site.urls),
    path('api/',include('store.api_urls')),
    path('',lambda r:page(r,'index.html')),
    path('<str:name>',page)
]
urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
