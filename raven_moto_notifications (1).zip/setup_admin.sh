#!/usr/bin/env bash
set -e
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
. .venv/bin/activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_data
python manage.py setup_admin
python manage.py runserver
