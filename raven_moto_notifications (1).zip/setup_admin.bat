@echo off
setlocal
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  py -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_data
python manage.py setup_admin
python manage.py runserver
